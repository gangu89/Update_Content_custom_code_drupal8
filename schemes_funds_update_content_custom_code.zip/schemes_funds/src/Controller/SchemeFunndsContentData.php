<?php

namespace Drupal\schemes_funds\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\image\Entity\ImageStyle;
use Drupal\Component\Utility\Html;
use Symfony\Component\HttpFoundation\Request;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Entity\Query\QueryFactory;
use Drupal\Core\Datetime\DrupalDateTime;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Drupal\Core\Url;
use Drupal\Core\Routing;
use Drupal\Core\Field\EntityReferenceFieldItemList;
use Drupal\node\Entity\Node;



use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Reader\IReader;
use PhpOffice\PhpSpreadsheet\Writer\IWriter;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;


/**
 * Controller to update Scheme Funds Content.
 */
class SchemeFunndsContentData extends ControllerBase
{
  /**
   * {@inheritdoc}
   */
  protected $entityTypeManager;
  /**
   * {@inheritdoc}
   */
  protected $cacheBackend;
  /**
   * {@inheritdoc}
   */
  protected $entityQuery;

  /**
   * {@inheritdoc}
   */
  public function __construct(EntityTypeManagerInterface $entityTypeManager, CacheBackendInterface $cacheBackend, QueryFactory $entityQuery)
  {
    $this->entityTypeManager = $entityTypeManager;
    $this->cacheBackend = $cacheBackend;
    $this->entityQuery = $entityQuery;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container)
  {
    return new static(
      $container->get('entity.manager'),
      $container->get('cache.default'),
      $container->get('entity.query')
    );
  }

  public function SchemeFunndsContent()
  {
    
    $base_url = Request::createFromGlobals()->getSchemeAndHttpHost();
    $request = \Drupal::request();
    $storage = \Drupal::service('entity_type.manager')->getStorage('node');

    /**** File reader function */

    $filepath = $_SERVER['DOCUMENT_ROOT'].'/Scheme_Sectors.xlsx'; 
    $scheme_stock_filepath = $_SERVER['DOCUMENT_ROOT'].'/Scheme_Stock_Holdings.xlsx';
//echo '<pre>';print_r($filepath); exit;
    //if (isset($filepath)) {       
      $spreadsheet = new Spreadsheet();
// echo '<pre>';print_r($spreadsheet); exit;
       //Read Scheme_Sectors.xlsx 
      $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($filepath);
      $totalrows=$spreadsheet->setActiveSheetIndex(0)->getHighestRow(); //Count Numbe of rows avalable in excel
      $objWorksheet=$spreadsheet->setActiveSheetIndex(0);  
      for($i=2;$i<=$totalrows;$i++)
      { 
       $details [] = ['scheme_code' => $objWorksheet->getCellByColumnAndRow(1,$i)->getValue(),'sector' =>$objWorksheet->getCellByColumnAndRow(2,$i)->getValue(),'holding_percent' =>$objWorksheet->getCellByColumnAndRow(3,$i)->getValue() ];
      }
       //Read Scheme_Stock_Holdings.xlsx 
      $spreadsheet_stock = \PhpOffice\PhpSpreadsheet\IOFactory::load($scheme_stock_filepath);
      $totalrows_stock=$spreadsheet_stock->setActiveSheetIndex(0)->getHighestRow(); //Count Numbe of rows avalable in excel
      $objWorksheet_stock=$spreadsheet_stock->setActiveSheetIndex(0);  
      for($i=2;$i<=$totalrows_stock;$i++)
      { 
       $stock_details [] = ['scheme_code' => $objWorksheet_stock->getCellByColumnAndRow(1,$i)->getValue(),'sector' =>$objWorksheet_stock->getCellByColumnAndRow(2,$i)->getValue(),'holding_percent' =>$objWorksheet_stock->getCellByColumnAndRow(3,$i)->getValue() ];
      }
            
    //}
   // echo '<pre>';print_r($stock_details); exit;
    $query = \Drupal::entityQuery('node')
      ->condition('status', 1) //published or not
      ->condition('type', 'schemes_funds_update') //content type      
      ->pager(10); //specify results to return
    $nids = $query->execute();
    // echo '<pre>';print_r($nids);exit; 
    foreach ($nids as $nodeID) {
      $scheme_node_fields = $this->entityTypeManager->getStorage('node')->load($nodeID);    
      $node_title =$scheme_node_fields->get('title')->value;
      //echo '<pre>';print_r($scheme_node_fields->field_sector_update->getValue());exit;


      foreach($details as $d_key =>$d_val){
        if($node_title == $d_val['scheme_code']){
          
              if ($scheme_node_fields != NULL && $scheme_node_fields->bundle() == "schemes_funds_update" && $scheme_node_fields->status->value == 1) {
                if (!$scheme_node_fields->field_sector_update->isEmpty()) {
                  $scheme_node_fields_items = $scheme_node_fields->field_sector_update->getValue();    
                  //echo '<pre>';print_r($scheme_node_fields_items);exit;
                    foreach ($scheme_node_fields_items as $scheme_funds_item) {
                      $sector_paragraph_details = Paragraph::load($scheme_funds_item['target_id']); 
                      $paragraph_type = $sector_paragraph_details->getType();                      
                      if($paragraph_type == 'sectors_update'){
                        // echo '<pre>';print_r($type);exit;
                      $fieldd_sector_update = $sector_paragraph_details->get('field_sector_update')->value;
                      $field_sectorholding_update = $sector_paragraph_details->get('field_sectorholding_update')->value;
                     
                      if(strtolower($fieldd_sector_update) == strtolower($d_val['sector'])){
                        //echo '<pre>';print_r($fieldd_sector_update .'**'.$d_val['holding_percent']);
                        if(!empty($d_val['holding_percent'])){
                          $sector_paragraph_details->set('field_sectorholding_update', $d_val['holding_percent']);
                          $sector_paragraph_details->save(); 
                          $my_module_template_sector = 'Sectors Content is Updated'.'<br/>'; 
                        }else{
                          $my_module_template_sector = 'Sectors Content is not Update'.'<br/>';  
                        }
  
                        
                      }
                      }                   

                    }
                    // exit;
                }
            }

        }
      }
      
      //
      foreach($stock_details as $stock_key =>$stock_val){
        if($node_title == $stock_val['scheme_code']){
          // echo '<pre>';print_r($node_title);exit;
              if ($scheme_node_fields != NULL && $scheme_node_fields->bundle() == "schemes_funds_update" && $scheme_node_fields->status->value == 1) {
                if (!$scheme_node_fields->field_sector_update->isEmpty()) {
                  $stock_scheme_node_fields_items = $scheme_node_fields->field_sector_update->getValue();    
                //  echo '<pre>';print_r($stock_scheme_node_fields_items);exit;
                    foreach ($stock_scheme_node_fields_items as $stock_scheme_funds_item) {
                      // echo '<pre>';print_r($stock_scheme_funds_item);
                      $stock_paragraph_details = Paragraph::load($stock_scheme_funds_item['target_id']); 
                      $stock_paragraph_type = $stock_paragraph_details->getType();
                      // echo '<pre>';print_r($stock_paragraph_details);
                      if($stock_paragraph_type == 'stocks'){
                        // echo '<pre>';print_r($stock_paragraph_type);exit;
                      $fieldd_sector_update = $stock_paragraph_details->get('field_stocks')->value;
                      $field_sectorholding_update = $stock_paragraph_details->get('field_stocksholding')->value;
                     
                      if(strtolower($fieldd_sector_update) == strtolower($stock_val['sector'])){
                        // echo '<pre>';print_r($fieldd_sector_update .'**'.$stock_val['holding_percent']);exit;
                      if(!empty($stock_val['holding_percent'])){
                        $stock_paragraph_details->set('field_stocksholding', $stock_val['holding_percent']);
                        $stock_paragraph_details->save(); 
                       
                        $my_module_template_stock = 'Stocks Content is Updated'.'<br/>';  
                      }else{
                        $my_module_template_stock = 'Stocks Content is not Update '.'<br/>';  
                        
                         }                        
                         }
                      }             
                    }
                  //exit;
                }
            }
        }
      }
      // exit;
       

    } //All Node loop Ends
    //exit;
//$my_module_template = 'gangadhara';
    return array(
      '#markup' => $my_module_template_sector .$my_module_template_stock
    );
    
  } //End SchemeFunndsContent loop

}
