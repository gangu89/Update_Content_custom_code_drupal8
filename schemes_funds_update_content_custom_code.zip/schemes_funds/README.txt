Install phpoffice library by using composer
 
composer require phpoffice/phpspreadsheet
